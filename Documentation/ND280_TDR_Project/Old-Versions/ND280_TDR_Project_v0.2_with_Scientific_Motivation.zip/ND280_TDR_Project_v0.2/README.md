# ND280 Magnetic Field Monitoring System — TDR v0.2

This package contains the LaTeX source of the Technical Design Report.

## Main changes from v0.1

- Added Chapter 2: Scientific Motivation.
- Integrated the supplied HA-TPC magnetic-field material.
- Converted the supplied references into BibTeX.
- Renumbered the remaining chapters.
- Added List of Figures and List of Tables.
- Kept the TDR as a single system document covering the Reference Node, Eight-Sensor Multiplexing Node, NodeOS, ND280 Monitor, distributed architecture and validation.

## Build

Recommended command sequence:

    pdflatex main.tex
    bibtex main
    pdflatex main.tex
    pdflatex main.tex

You can also use TeXstudio and select BibTeX in the build chain.

## Note

The bibliography entries reproduce the references supplied for the HA-TPC magnetic-field material. They can be refined later with final DOI, journal volume, page and collaboration metadata.
